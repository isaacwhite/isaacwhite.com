Isaac White
iaw2105
lab4

The program works as specified/provided. It takes input in the form of command line args for the database file to search, and if none is provided quits and informs of proper usage. There are also some commented out sections that could be used to print back the input value to the user or print the truncated search term, but these are not necessary to the functionality of the program and are there just for testing purposes. 

All functionality was built into the file called my-mdb-add.c, and it is necessary to compile the contents of lab3/solutions/part1 before compilation and linking of my-mdb-add is possible. The executable created is called my-mdb-add.

====VALGRIND OUTPUT====
(ran with search Jae, followed by ctrl+d)

==13275== Memcheck, a memory error detector
==13275== Copyright (C) 2002-2011, and GNU GPL'd, by Julian Seward et al.
==13275== Using Valgrind-3.7.0 and LibVEX; rerun with -h for copyright info
==13275== Command: ./my-mdb-lookup /home/jae/cs3157-pub/bin/mdb-cs3157
==13275== Parent PID: 4273
==13275== 
==13275== 
==13275== HEAP SUMMARY:
==13275==     in use at exit: 0 bytes in 0 blocks
==13275==   total heap usage: 874 allocs, 874 frees, 25,024 bytes allocated
==13275== 
==13275== All heap blocks were freed -- no leaks are possible
==13275== 
==13275== For counts of detected and suppressed errors, rerun with: -v
==13275== ERROR SUMMARY: 0 errors from 0 contexts (suppressed: 2 from 2)
