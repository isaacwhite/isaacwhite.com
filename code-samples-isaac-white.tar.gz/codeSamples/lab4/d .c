[33mcommit 2c205ebc0483fa1a5cf9c19b3748660d75cdf739[m
Author: Isaac White <iaw2105@columbia.edu>
Date:   Sat Mar 16 22:56:19 2013 -0400

    Removed my-mdb used for testing purposes

[33mcommit d03d9e4e40971c1a7285adf5ed979e9c19d19446[m
Author: Isaac White <iaw2105@columbia.edu>
Date:   Sat Mar 16 22:53:00 2013 -0400

    Added information to readme and added check for no database parameter

[33mcommit ba8cabd0d172f09714685368208a092536e5ca74[m
Author: Isaac White <iaw2105@columbia.edu>
Date:   Sat Mar 16 22:10:05 2013 -0400

    Fixed errors with search term by null terminating using (char) 0, commented

[33mcommit e20512684a2881822b2f728d6deb047cbf9bc78f[m
Author: Isaac White <iaw2105@columbia.edu>
Date:   Sat Mar 16 21:32:56 2013 -0400

    Added conditional to check if strings match before print
    
    -Error occurs if string is less than 5 characters

[33mcommit 87c1ec572d03aa766b5ec43b3d81a88448b4a5d7[m
Author: Isaac White <iaw2105@columbia.edu>
Date:   Sat Mar 16 20:40:51 2013 -0400

    Added EOF detection and eliminated reference files

[33mcommit 93ef5b5602a1e969e48034acba9773cd7174e463[m
Author: Isaac White <iaw2105@columbia.edu>
Date:   Sat Mar 16 19:18:36 2013 -0400

    Added frees to elminate memory leaks

[33mcommit 3ba75f7eb37ec7cf97d8fc476668ebe3905ac041[m
Author: Isaac White <iaw2105@columbia.edu>
Date:   Sat Mar 16 18:48:45 2013 -0400

    Got a working setup for printing all entries without search

[33mcommit 5e63030d7100e1744c78b3ca908c8974c43485d8[m
Author: Isaac White <iaw2105@columbia.edu>
Date:   Sat Mar 16 17:05:29 2013 -0400

    Testing effect of struct call on each mdbrec

[33mcommit 124d6374b872430082cb88761ade01361da0cc00[m
Author: Isaac White <iaw2105@columbia.edu>
Date:   Sat Mar 16 16:16:36 2013 -0400

    Adding files for experimentation

[33mcommit bc424638960255f172007748b73979307f3493ff[m
Author: Jae Woo Lee <jae@cs.columbia.edu>
Date:   Fri Mar 1 18:17:18 2013 -0500

    Lab 4 skeleton files
