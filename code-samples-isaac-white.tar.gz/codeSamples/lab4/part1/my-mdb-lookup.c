#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "mylist.h"
#include "mdb.h"

int entryNumber=1;
char search[6];
void printEntry(void *rec) {
    const char* name;//pointer to the name
    const char* msg;//pointer to the message
    name = (char*)(((struct MdbRec*)rec)->name);//assign pointer
    msg = (char*)(((struct MdbRec*)rec)->msg);//assign pointeri
    //check if string is in either name or message
    if(strstr((msg),((const char*)search)) ||
        strstr((name),((const char*)search))) {
        //if so, print the message
        printf ("%3d: ", entryNumber);
        printf("{%s} said ", (char*) ((struct MdbRec*)rec)->name);
        printf("{%s}\n", (char*) ((struct MdbRec*)rec)->msg);
    }
        entryNumber++;//increment entry number
}
void popFrontData(struct List* list){//special case to free data too
    //only used to clear out all memory, so no return of new front necessary
    if (isEmptyList(list)) {
       ; //do nothing, no return
    } else {
        struct Node* tempHead = list->head;
        list->head = tempHead->next;
        free(tempHead->data);//free malloc'd record
        free(tempHead);//free the node
    } //don't return anything;
}
void removeAllNodesData(struct List* list) {
       while (isEmptyList(list) == 0) {//if the list isn't empty
           popFrontData(list);//call special popFrontData
       }
}
int main(int argc, char** argv) {
   struct List list;
    initList(&list);

    if(argc < 2) {
        printf("usage: mdb-lookup <database_file>\n");
        exit(1);
    }
    FILE* fp =  fopen(argv[1], "rb");
    void* temp= malloc(sizeof(struct MdbRec));//temporary MdbRec strucure
    if (temp == NULL) {
        perror("malloc returned NULL");
        exit(1);
    }
    struct Node* current = (struct Node*) list.head;        
    while(fread(temp,sizeof(struct MdbRec), 1, fp)!=0) {
        struct MdbRec* rec;
        rec = (struct MdbRec*) malloc(sizeof(struct MdbRec));
        if (rec == NULL) {
            perror("malloc returned NULL");
            exit(1);
        }
        *rec = *(struct MdbRec*) temp;
        current = addAfter(&list, current, rec);
    }  
 
    search[5]= (char)0;//null terminate search string outside while
    char input[1000];//buffer to store input string
    char w;//char to set fgetc to
      while (!feof(stdin)) {//while not EOF signal
        int i=0; 
        printf("lookup: ");
        for (i=0; i<1000; i++){
            input[i]= (char)0;//null the string from previous inputs
        }
        i=0;
        //while w is not EOF or new line or past end of input
        while ((w=fgetc(stdin)) && (w!=EOF) && (w != '\n') && i<1000) {
            input[i] = w;
            i++;
        }
        input[i]=(char)0; //terminate the string

        /* Test function for printing input string 
        printf("You asked to lookup: ");
        i=0;
        //while haven't reached new line character
        while ((input[i] != '\n') && (input[i]!=0) && i<1000){
            printf("%c",input[i]);
            i++;
        }
        */
        for (i=0; i<5; i++) {
            search[i]=(char)0;//null the string from prev input
        }  
        
        strncpy(search, (const char*)input, 5);
        /*Test print of search term and string length
        printf("String Length: %u", (unsigned)strlen(input)); 
        printf("\nSearch: %s", search);
        printf("\n"); //add new line
        */
        entryNumber=1;//reset entry numbers from previous runsi
        //need to check the following to make sure you don't print on program exit
        if(w!=EOF) {traverseList(&list, &printEntry);}//traverse list and find searhc term
    }
    free(temp);//free temporary pointer
    removeAllNodesData(&list);//remove nodes and data
    fclose (fp);//close file
    return 0;//exit
}

