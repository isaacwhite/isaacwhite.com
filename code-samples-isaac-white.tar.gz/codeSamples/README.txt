*************************
  GUIDE TO CODE SAMPLES
*************************

isaacwhite.com - personal resume site to host portfolio and experience info. Created 03.21.2013. Images and git history removed for reducing file size. Hosted in full at https://github.com/isaacwhite/isaacwhite.com 

lab4 - c code database lookup program written for class in C programming. Created 03.16.2013

columbiaspectator.com - selected samples from source code for spectator redesign. Launched 4.9.2013. 
--specstyle.scss and compiled specstyle.css for visual style of columbiaspectator.com. 
--page.tpl.php, page templating file for Drupal page render. Interstitial ads code added by co-editor. Base settings provided by zen contributed Drupal theme.
--specscript.js, javascript/jQuery that controls showing and hiding of elements related to expand/collapse boxes as well as menu slidedown. Base comments provided by zen contributed theme.

core - PHP and jQuery adapted from php in use for views JSON encode block at college.columbia.edu (main content area). Modified from Drupal 7 for Drupal 6, and added touch events based on previous JS served at studentaffairs.columbia.edu/admissions. Last updated 4.19.2013

facultyProfile - HTML and CSS mockup made during design/mockup phase of Columbia admissions site. Last modified 5.20.2012


