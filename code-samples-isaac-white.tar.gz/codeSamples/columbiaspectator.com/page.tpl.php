<?php
/**
 * @file
 * Zen theme's implementation to display a single Drupal page.
 *
 * Available variables:
 *
 * General utility variables:
 * - $base_path: The base URL path of the Drupal installation. At the very
 *   least, this will always default to /.
 * - $directory: The directory the template is located in, e.g. modules/system
 *   or themes/bartik.
 * - $is_front: TRUE if the current page is the front page.
 * - $logged_in: TRUE if the user is registered and signed in.
 * - $is_admin: TRUE if the user has permission to access administration pages.
 *
 * Site identity:
 * - $front_page: The URL of the front page. Use this instead of $base_path,
 *   when linking to the front page. This includes the language domain or
 *   prefix.
 * - $logo: The path to the logo image, as defined in theme configuration.
 * - $site_name: The name of the site, empty when display has been disabled
 *   in theme settings.
 * - $site_slogan: The slogan of the site, empty when display has been disabled
 *   in theme settings.
 *
 * Navigation:
 * - $main_menu (array): An array containing the Main menu links for the
 *   site, if they have been configured.
 * - $secondary_menu (array): An array containing the Secondary menu links for
 *   the site, if they have been configured.
 * - $secondary_menu_heading: The title of the menu used by the secondary links.
 * - $breadcrumb: The breadcrumb trail for the current page.
 *
 * Page content (in order of occurrence in the default page.tpl.php):
 * - $title_prefix (array): An array containing additional output populated by
 *   modules, intended to be displayed in front of the main title tag that
 *   appears in the template.
 * - $title: The page title, for use in the actual HTML content.
 * - $title_suffix (array): An array containing additional output populated by
 *   modules, intended to be displayed after the main title tag that appears in
 *   the template.
 * - $messages: HTML for status and error messages. Should be displayed
 *   prominently.
 * - $tabs (array): Tabs linking to any sub-pages beneath the current page
 *   (e.g., the view and edit tabs when displaying a node).
 * - $action_links (array): Actions local to the page, such as 'Add menu' on the
 *   menu administration interface.
 * - $feed_icons: A string of all feed icons for the current page.
 * - $node: The node object, if there is an automatically-loaded node
 *   associated with the page, and the node ID is the second argument
 *   in the page's path (e.g. node/12345 and node/12345/revisions, but not
 *   comment/reply/12345).
 *
 * Regions:
 * - $page['header']: Items for the header region.
 * - $page['navigation']: Items for the navigation region, below the main menu (if any).
 * - $page['help']: Dynamic help text, mostly for admin pages.
 * - $page['highlighted']: Items for the highlighted content region.
 * - $page['content']: The main content of the current page.
 * - $page['sidebar_first']: Items for the first sidebar.
 * - $page['sidebar_second']: Items for the second sidebar.
 * - $page['footer']: Items for the footer region.
 * - $page['bottom']: Items to appear at the bottom of the page below the footer.
 *
 * @see template_preprocess()
 * @see template_preprocess_page()
 * @see zen_preprocess_page()
 * @see template_process()
 */
?>
<?php /*if($is_front):*/ ?>
<!-- FlexSlider Script -->
<script>
$(window).load(function() {
  if(!$('body').hasClass('node-type-article')) {
       var w = $(window).width();
        // if(992<w){
        //   $('.flexslider').flexslider({
        //     animation: "slide",
        //     animationLoop: true,
        //     itemWidth: 225,
        //     itemMargin: 0,
        //     minItems: 3,
        //     maxItems: 8,
        //     slideshowSpeed: 10000,
        //     pauseOnHover: true
        //   });
        //} else
         if (448 <w ) { //&& w<992
          $('.flexslider').flexslider({
            animation: "slide",
            animationLoop: true,
            itemWidth: 308,
            itemMargin: 0,
            minItems: 2,
            maxItems: 8,
            slideshowSpeed: 10000,
            pauseOnHover: true
          });
        } else {
          $('.flexslider').flexslider({
            animation: "slide",
            animationLoop: true,
            itemWidth: 448,
            itemMargin: 0,
            minItems: 1,
            maxItems: 8,
            slideshowSpeed: 10000,
            pauseOnHover: true
          });
        }
  }
});
</script>
<script>
    $(document).ready(function(){
if (document.cookie.indexOf('visited=true') === -1) {
  var expires = new Date();
  expires.setDate(expires.getDate()+30);
  document.cookie = "visited=true; expires="+expires.toUTCString();
  //$(".welcome-first-visit").colorbox({inline:true});
  $.colorbox({inline:true,href:".welcome-first-visit",width:"65%",scrolling:false});
 }
          });
</script>
<!--/* Interstitial or Floating DHTML Tag v2.8.7 */-->

<!--/*
     * This tag has been generated for use on a non-SSL page. If this tag
     * is to be placed on an SSL page, change the
     *   'http://www.oncampusweb.com/delivery/...'
     * to
     *   'https://www.oncampusweb.com/delivery/...'
     *
     *------------------------------------------------------------*
     * This interstitial invocation code requires the images from:
     * /www/images/layerstyles/simple/...
     * To be accessible via: http(s)://cdn.oncampusweb.com/layerstyles/simple/...
     *------------------------------------------------------------*
     */-->
<!--
<div class="IStest">
<script type='text/javascript'><!--//<![CDATA[
var w=$(window).width();
var h = $(window).height();
if(875< w && 650 < h) {
    var ox_u = 'http://www.oncampusweb.com/delivery/al.php?zoneid=1628&layerstyle=simple&align=center&valign=middle&padding=2&closetime=10&padding=2&shifth=0&shiftv=0&closebutton=t&backcolor=FFFFFF&noborder=t';
  if (document.context) ox_u += '&context=' + escape(document.context);
  document.write("<scr"+"ipt type='text/javascript' src='" + ox_u + "'></scr"+"ipt>");

 }
//]]>--></script>
</div>






<?php /*endif*/ ?>

<div id="page">
  <div id="wrapper">
    <header id="header" role="banner">
      <!-- user menu -->
      <?php if ($secondary_menu): ?>
        <nav id="secondary-menu" role="navigation">
          <?php print theme('links__system_secondary_menu', array(
            'links' => $secondary_menu,
            'attributes' => array(
              'class' => array('links', 'clearfix', 'user-nav', 'nav'),
            ),
            'heading' => array(
              'text' => $secondary_menu_heading,
              'level' => 'h2',
              'class' => array('element-invisible'),
            ),
          )); ?>
        </nav>
      <?php endif; ?>
      <!-- site logo -->
      <a href="/" class="back-image site-logo"></a>
      <!-- social media -->
      <?php print render($page['header_left']); ?>
      <?php if ($site_name || $site_slogan): ?>
        <hgroup id="name-and-slogan">
          <?php if ($site_name): ?>
            <h1 id="site-name">
              <a href="<?php print $front_page; ?>" title="<?php print t('Home'); ?>" rel="home"><span><?php print $site_name; ?></span></a>
            </h1>
          <?php endif; ?>

          <?php if ($site_slogan): ?>
            <h2 id="site-slogan"><?php print $site_slogan; ?></h2>
          <?php endif; ?>
        </hgroup><!-- /#name-and-slogan -->
      <?php endif; ?>

      <!-- search box block -->

      <?php print render($page['header']); ?>
  
    </header>

    
    <div id="main" class="grid">
      <div id="navigation">
        <div id="menu-wrapper">
          <?php if ($main_menu): ?>
            <nav id="main-menu" role="navigation">
              <?php
              // This code snippet is hard to modify. We recommend turning off the
              // "Main menu" on your sub-theme's settings form, deleting this PHP
              // code block, and, instead, using the "Menu block" module.
              // @see http://drupal.org/project/menu_block
              print theme('links__system_main_menu', array(
                'links' => $main_menu,
                'attributes' => array(
                  'class' => array('links', 'inline', 'clearfix'),
                ),
                'heading' => array(
                  'text' => t('Main menu'),
                  'level' => 'h2',
                  'class' => array('element-invisible'),
                ),
              )); ?>
            </nav>
          <?php endif; ?>
        </div>
        <div id="slide-nav-container">
          <?php print render($page['slide_nav']); ?>
          <div id="banner-ad">
            <?php print render($page['navigation']); ?>
           </div> 
        </div>
      </div><!-- /#navigation -->
      
  
      <div id="main-container" class="<?php if(empty($page['col_side'])) { print 'no-col-side'; } ?><?php if(empty($page['col_side_opp'])) { print ' no-col-side-opp'; } ?>">
          <div id="col-main" class="column" role="main">
          <?php if (($title) && (!$is_front)): ?>
            <h1 class="title article-heading-main" id="page-title"><?php print $title; ?></h1>

      <?php endif; ?>
         
        
          <?php print $messages; ?>
          <?php if (!$is_front): ?>
            <?php print render($tabs); ?>
          <?php endif ?>
          <?php print render($page['content']); ?>
        </div>

        <?php if ($page['col_side']): ?>
          <div id="col-side" class="column">
            <?php print render($page['col_side']); ?>
          </div>
        <?php endif ?>

        <?php if ($page['col_side_opp']): ?>
          <div id="col-side-opposite" class="column">
            <?php print render($page['col_side_opp']); ?>
          </div>   
        <?php endif ?>
        <!-- /#content -->
      </div> <!-- main-container -->

      <div class="footer-region">
        <?php print render($page['footer']); ?>
      </div>

    </div>   <!-- /#main -->
      
    <?php print render($page['bottom']); ?>
  </div> <!--wrapper-->
</div><!-- /#page -->

