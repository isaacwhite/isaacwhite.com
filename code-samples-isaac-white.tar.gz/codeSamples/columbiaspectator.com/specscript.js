/**
 * @file
 * A JavaScript file for the theme.
 *
 * In order for this JavaScript to be loaded on pages, see the instructions in
 * the README.txt next to this file.
 */

// JavaScript should be made compatible with libraries other than jQuery by
// wrapping it with an "anonymous closure". See:
// - http://drupal.org/node/1446420
// - http://www.adequatelygood.com/2010/3/JavaScript-Module-Pattern-In-Depth
(function ($, Drupal, window, document, undefined) {
	
	//THESE VARIABLES ARE FOR THE MENU BAR
	var y1, y2;
	var x;
	var deltaY;
	var elementHeight;
	var elementLocationY;
	var elementLocationX;
	var isBelowElement;
	var isAboveElement;
	var isLeftOfElement;
	var movingDown;

	$(document).mousemove(function(e) {
		
		//THIS IS ALL FOR THE MENU BAR
		setTimeout(function(){
			y2 = y1;
			y1 = e.pageY; //y1 is the new value
			x = e.pageX;
			elementHeight = $('#main-menu li').height();
			elementLocationY = $('#main-menu li').offset().top;
			elementLocationX = $('#main-menu li').offset().left;
			deltaY = y1 - y2;
			isAboveElement = y1 < elementLocationY;
			isBelowElement = y1 > (elementLocationY + elementHeight);
			isLeftOfElement = x < elementLocationX;

			//In these cases, mouse is off the menu bar, close the dropdown
			if (isLeftOfElement || isAboveElement){
				$('#main-menu').find('li').removeClass('hovered');
				$('.region-slide-nav').removeClass("unhidden");
			}
			//These cases are needed for when the mouse is over the menubar
			else if (deltaY < 0){
				movingDown = 0;
			}
			else if (isBelowElement || deltaY > 0){
				movingDown = 1;
			}

		}, 1);
	});


$(function() {
	// expand and collapse function
	$('.section-box .section-box-expand-collapse').click(function() {
		if (!$(this).closest('.section-box').hasClass("expanded")) {
			var expanded = $('#col-main').find('.expanded');
			expanded.removeClass("expanded"); //close the other boxes
			expanded.find('.section-box-expand-collapse').html("+"); //change the icon
			$(this).closest('.section-box').addClass("expanded");
			$(this).html("-");
			//$(this).closest('section-box').removeClass("collapsed");
		} else if ($(this).closest('.section-box').hasClass("expanded")) {
			//$(this).closest('section-box').addClass("collapsed");
			$(this).closest('.section-box').removeClass("expanded");
			$(this).html("+");
		};
	});

			

		
			
			$('#main-menu li').hover(function() {
				$('#main-menu').find('li').removeClass('hovered');
				$(this).addClass('hovered'); //highlight the li
			},
			function() {
				//If not moving down and leaving nav bar, hide the slider.
				if (movingDown == 0){
					$('.region-slide-nav').removeClass("unhidden");
					$(this).removeClass('hovered');
				}
			});

			$('.region-slide-nav').hover(function(){

			}, function(){
				$('.region-slide-nav').removeClass("unhidden");
				$('#main-menu').find('li').removeClass('hovered');
			});

			//news
			$('#main-menu li.menu-470').hover(function() { //333
				//find anything with news in the id
				$('.region-slide-nav').addClass("unhidden");
				$('.region-slide-nav').find("div").removeClass("unhidden");
				$('.region-slide-nav').find("div[id$='news']").addClass("unhidden");
			},
			function() {
				//empty function, do nothing on mouseout
				
			});

			//opinion
			$('#main-menu li.menu-471').hover(function() {
				//find anything with opinion in the id
				$('.region-slide-nav').addClass("unhidden");
				$('.region-slide-nav').find("div").removeClass("unhidden");
				$('.region-slide-nav').find("div[id$='opinion']").addClass("unhidden");
			},
			function() {
				//empty function, do nothing on mouseout
			});

			//a&e
			$('#main-menu li.menu-472').hover(function() {
				$('.region-slide-nav').addClass("unhidden");
				$('.region-slide-nav').find("div").removeClass("unhidden");
				$('.region-slide-nav').find("div[id$='ae']").addClass("unhidden");
				$('.region-slide-nav').find("div[id$='a-e']").addClass("unhidden"); //alternate case for menu
			},
			function() {
				//empty function, do nothing on mouseout
			});

			//sports
			$('#main-menu li.menu-473').hover(function() {
				$('.region-slide-nav').addClass("unhidden");
				$('.region-slide-nav').find("div").removeClass("unhidden");
				$('.region-slide-nav').find("div[id$='sports']").addClass("unhidden");
			},
			function() {
			 	//empty function, do nothing on mouseout
			});

			//multimedia
			$('#main-menu li.menu-474').hover(function() {
				$('.region-slide-nav').addClass("unhidden");
				$('.region-slide-nav').find("div").removeClass("unhidden");
				$('.region-slide-nav').find("div[id$='multimedia']").addClass("unhidden");
			},
			function() {
			 	//empty function, do nothing on mouseout
			});

			$('#main-menu li.menu-475').hover(function() {
				$('.region-slide-nav').removeClass("unhidden");
			},
			function(){
				$(this).removeClass("hovered");
			});

			$('#main-menu li.menu-476').hover(function() {
				$('.region-slide-nav').removeClass("unhidden");
			},
			function(){
				$(this).removeClass("hovered");
			});

			$('#main-menu li.menu-477').hover(function() {
				$('.region-slide-nav').removeClass("unhidden");
			},
			function(){
				$(this).removeClass("hovered");
			});

	// Social Center Tabs
	$('#social-center-tabs').tabify(function(){});

});


          
    
})(jQuery, Drupal, this, this.document);



