<?php
	// see full view object using dpm, a devel function that uses the drupal_set_message function
	$v = views_get_view("feature", "block_1");
	// dpm($v);
	
	// FEATURED STORIES ***
	// get featured story nodes
	$status = 1;
	$feature = 'feature';
	$courseid = 2401; //and field_feature_relates_to[0]['nid']=%d", $courseid
	
	$result = db_query("SELECT nid, title FROM {node} WHERE type='%s' and status=%d", $feature, $status); //select only those stories that are indicated as featured
	//D7 QUERY// $result = db_query("SELECT nid, title FROM {node} WHERE type = :type and status = :status", array(':type' => 'featured_story', ':status' => '1'));
	$node_info = array(); //declare array node_info
	$record;
	// print $result;
	//Get current month and set a string to compare to later
	$month = date('m');
	if ($month < 7) {
		$month = 'spring';
	} else {
		$month = 'fall';
	}
	// $month = 'fall';
	// print $month;
	while ($value = db_fetch_array($result)){//set each row to value and assign fields) {
		//do something with each $record
		// dpm($value);
		// print($value['nid'] + "\n");
		// $story_node = node_load($value->nid);	
		$story_node = node_load($value['nid']);	//load the node
		// dpm($story_node);
		$related_node = node_load($story_node->field_feature_relates_to[0]['nid']); //load the related content
		// dpm($related_node);
		$related_node_semester = $related_node->field_text_semester[0]['value'];//semester as string
		$related_node_course = $related_node->taxonomy[0]->tid;//first course as tid
		
		$terms = taxonomy_node_get_terms($related_node, $key = 'tid'); //get the taxonomy term
	    foreach ($terms as $term) {
	        if ($term->tid == 42) {//check if it is associated with LitHum
	            // print date('m');
	        	if ($related_node_semester == $month){
	        	// dpm($related_node);
				$story_summary = html_entity_decode($story_node->teaser,ENT_QUOTES, "UTF-8");//render html markup for summary field, specifying UTF-8 encoding
				// dpm($story_node);
				$story_photo = imagecache_create_url('top_image',$story_node->field_image_with_cropping[0]['filepath'], FALSE, TRUE);//image style name, path to image
				$node_info[] = array($related_node->nid,$related_node->title,$story_summary,$story_photo);
	        		
	        	} //no else
	        } //no else
	    }

	}
	// dpm($node_info);
	$story_count = count($node_info);
	$current_story = 0;
	$story_view = views_get_view("feature"); 
	
	// if there is more than one story, select a random story to start with
	if ($story_count > 1) {
		$t = gettimeofday();
		$us = $t[usec];
		$rand = round(($us/1000000)*($story_count-1));
		$current_story = $rand;
	}
	// get html for the featured story view
	$current_story_nid = $node_info[$current_story][0];
	$story_html = $story_view->preview('featured_story_block',array($current_story_nid));

//?>

<?php 
if ($story_count > 0 ):// ?>
	<div class="featuredcontent <?php print $view_state; ?>">
		 <?php if ($story_count > 0) { print $story_html; } ?>
		<script type="text/javascript">

			var swipeOptions = {
				swipe: swipe,
				threshold: 25,
				allowPageScroll: 'vertical'
			}
			$(function() {
				//Enable swiping...
				$(this.divParent).swipe(swipeOptions);
			});
			//Swipe handlers.
			function swipe(event, direction) {
				if(direction.indexOf("right") != -1){
					direction = "1";
				}
				else if(direction.indexOf("left") != -1){
					direction = "-1";
				}
				CycleStory(direction);
			}
		<!--
			// get array of node ids from drupal
			var stories = <?php print drupal_to_js($node_info); ?>;
			var current_story = <?php print $current_story; ?>;
			
			// identify the HTML elements for the featured stories
			var story_code = jQuery('.featuredcontent');
			
			// do not do anything if there is a large featured news story
			
				// add controls for cycling through stories
				story_code.css('paddingBottom','0px').append('<menu class="controls"></menu><div class="timer"></div>');
				
				// identify HTML elements for the controls
				var controls = jQuery('.featuredcontent .controls');
				var timer = jQuery('.featuredcontent .timer');
		
				var story_duration = 12;
				
				//BULLET FUNCTIONALITY TAKEN OUT FOR THIS CASE
				// add a bullet in the display for each story
				// var x;
				// for (x=0; x<stories.length; x++) {
				// 	var class_code = "";
				// 	if (x == current_story) { class_code = ' class="selected"'; }
				// 	controls.find("ul").eq(0).append('<li'+class_code+'>'+(x+1)+'</li>');
				// }
				
				// add next and previous buttons
				controls.prepend('<div class="arrow prev">Previous</div>');
				controls.append('<div class="arrow next">Next</div>');
				
				// start the timer for the current story
				timer.css('width','1%').animate({'width':'100%'},(story_duration*1000),'linear',function(){ CycleStory(1); });
				
				//BULLET FUNCTIONALITY TAKEN OUT FOR THIS CASE
				// when clicking on a bullet in the display, go to the story represented by that bullet
				// controls.find("li").click(function(){ 
				// 	// window.alert("Hi "+ jQuery(this).text());
				// 	var i = jQuery(this).text() - 1;
				// 	story_code.find('.views-row').fadeOut(500,function(){
				// 		SwitchStory(i);
				// 		story_code.find('.views-row').fadeIn(500);
				// 		current_story = i;
				// 		timer.stop().css('width','1%').animate({'width':'100%'},(story_duration*1000),'linear',function(){ CycleStory(1); });
				// 	});
				// });
				
				// enable next and previous buttons
				controls.find(".arrow").click(function(){ 
					var i;
					if (jQuery(this).hasClass('next')) { i = (current_story + 1) % (stories.length); }
					else { 
						i = current_story - 1;
						if (i < 0) { i = i + stories.length }
					}
					story_code.find('.views-row').fadeOut(500,function(){
						SwitchStory(i);
						story_code.find('.views-row').fadeIn(500);
						current_story = i;
						timer.stop().css('width','1%').animate({'width':'100%'},(story_duration*1000),'linear',function(){ CycleStory(1); });
					});
				});
			//}
			//HAMMER.JS REQUIRES JQUERY 1.7, using alternate library for touch events (touchmove)

			// $(".view-feature").hammer().bind("swipeleft", function() {
			// 	alert('you swiped left!');

			//     i = (current_story + 1) % (stories.length);
			//     story_code.find('.views-row').fadeOut(500,function(){
			// 		SwitchStory(i);
			// 		story_code.find('.views-row').fadeIn(500);
			// 		current_story = i;
			// 		timer.stop().css('width','1%').animate({'width':'100%'},(story_duration*1000),'linear',function(){ CycleStory(1); });
			// 	});
			// });

			// $(".view-feature").hammer().bind("swiperight", function() {
			// 	alert('you swiped right!');
			//    i = current_story - 1;
			// 			if (i < 0) { i = i + stories.length }
			//     story_code.find('.views-row').fadeOut(500,function(){
			// 		SwitchStory(i);
			// 		story_code.find('.views-row').fadeIn(500);
			// 		current_story = i;
			// 		timer.stop().css('width','1%').animate({'width':'100%'},(story_duration*1000),'linear',function(){ CycleStory(1); });
			// 	});
			// });
			
			// function to switch to a particular story
			function SwitchStory(i) {
				story_code.find('.views-field-field-feature-relates-to-nid a').attr('href','/core/node/'+stories[i][0]);
				story_code.find('.views-field-field-feature-relates-to-nid a').text(stories[i][1]);
				story_code.find('.views-field-body .field-content').html(stories[i][2]);
				story_code.find('.views-field-field-image-with-cropping-fid .field-content img').attr('src',stories[i][3]);			
				
				controls.find('.selected').removeClass('selected');
				controls.find('li').eq(i).addClass('selected');
			}
			
			// function to cycle to the next story
			function CycleStory(d) {
				var next_story = (current_story + 1) % (stories.length);
				if (d < 0) {
					next_story = current_story - 1;
					if (next_story < 0) { next_story = next_story + stories.length }
				}
				story_code.find('.views-row').fadeOut(1000,function(){
					SwitchStory(next_story);
					story_code.find('.views-row').fadeIn(1000);
					current_story = next_story;
					timer.stop().css('width','1%').animate({'width':'100%'},(story_duration*1000),'linear',function(){ CycleStory(1); });
				});
			}
		//-->
		</script>


	</div>
	<?php endif; ?>